./chatserver
./station -no ifaces/ifaces.a rtables/rtable.a hosts <ip of chatserver> <port of chatserver>