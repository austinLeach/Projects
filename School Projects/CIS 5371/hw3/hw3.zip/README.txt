Run using 
python3 rhoattack.py

Program will print out initial x0 and then if it finds a collision it will print out the collision.
It will then try to find a collision again with the tortoise and tortoise race.
After it will print out a x and x' where x != x' and the full sha256 hash of each where the collision was found.