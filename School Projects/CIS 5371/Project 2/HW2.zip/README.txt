Austin Leach

To run the program use the command
python3 client.py

The program will ask for the port number on the server.
Type it in and hit enter and it will then start the attack.
The program outputs the best message it has so far each time a byte is recovered.
The program ends when it is finished.