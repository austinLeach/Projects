bigrams.py takes the war-and-peace.txt and calculates the bigrams from it and outputs bigrams.txt

montecarlo.py needs input.txt as an input of encrypted text and outputs output.txt after 10000 iterations
with the best found key and the best found decryption

Sometimes the random key can not make it to the true key and needs to be run multiple times in order to get to it